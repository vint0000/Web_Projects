<h4>Code Dynamic Websites with PHP</h4>
<h5>Copyright &copy;<?php echo date('Y');?> <a href="http://bradhussey.ca/" target="_blank">Brad Hussey</a> of <a href="http://codecollege.ca" target="_blank">CodeCollege.ca</a></h5>

