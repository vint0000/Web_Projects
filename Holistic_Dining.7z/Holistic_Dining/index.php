<?php
define("TITLE","Home|Holistic Dining");
include('includes/header.php');
?>
<div id="philosophy">
  <hr>

  <h1>Holistic Dining</h1>
  <p> Here at Holistics,we know that good food isn't just about how expensive the dish is.
    We're not pompous,we're proud of our work,our quality,our enviroment,and our love for food and family</p>

    <hr>
  </div><!-- philosophy-->
  <?php
  include('includes/footer.php');
  ?>
