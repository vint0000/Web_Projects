<div id="footer" class="cf">
  <div class="column three">
    <strong>Phone</strong>
    405.719.1055
  </div><!--column three-->
  <div class="column three">
    <strong>Location</strong>
    1001 G,East Brooks Street<br>
    Norman,OK 73071
  </div><!--column three-->
  <div class="column three last">
    <strong>Hours</strong>
    <em>Monday-Friday</em><br>
    9:00AM-5:00PM<br><br>

    <em>Saturday-Sunday</em><br>
    Closed<br><br>

    <?php  include("includes/store-hours.php"); ?>
  </div><!--column three last-->
</div><!--footer-->
<small>&copy;<?php echo date('Y')?>&nbsp;<?php echo $companyName?></small>
</div><!--content-->
</div><!--wrapper-->
</body>
</html>
