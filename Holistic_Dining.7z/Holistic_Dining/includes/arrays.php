<?php

//All Nav Items
$navItems=array(
  array(
    'link'  => "index.php",
    'title' => "Home"
  ),
  array(
    'link'  => "team.php",
    'title' => "Team"
  ),
  array(
    'link'  => "menu.php",
    'title' => "Menu"
  ),
  array(
    'link'  => "contact.php",
    'title' => "Contact"
  ),
);
//Team Members

$teamMembers=array(
  array(
    'name'  => "Frankie 111",
    'bio'   => "Frankie is the owner of Holistic Dining.",
    'img'  => "frankie"
  ),
  array(
    'name'  => "Francis",
    'bio'  => "Francis is the General Manager of Holistic Dining.",
    'img'  => "francis"
  ),
  array(
    'name'  => "Carlos",
    'bio'   => "Carlos is the chief chef of Holistic Dining.",
    'img'  => "carlos"
  ),

);

//Menu items

$menuItems=array(
  "club-sandwitch" => array(
    'title'        => "Club Sandwitch",
    'price'        => 11,
    'blurb'        => "Bacon ipsum dolor sit amet
                       fatback landjaeger ullamco pariatur.
                       Nostrud laboris et, duis drumstick eiusmod
                       kevin ut aliquip. Filet mignon short ribs tenderloin
                       short loin kielbasa non pork chop aliqua. Jerky shank
                       tri-tip capicola, non andouille tenderloin cupidatat turducken
                       meatball pork beef eu shoulder jowl.",
    'drink'        => "club soda"
  ),
  "dill-salmon" => array(
    'title'        => "Dill salmon",
    'price'        => 18,
    'blurb'        => "Pork belly tempor ground round
                      qui exercitation, jowl leberkas sed voluptate excepteur
                      jerky. Reprehenderit veniam cow, quis in ribeye andouille
                      eu pastrami eiusmod exercitation dolor",
    'drink'        => "Coke"
  ),
  "super-salad" => array(
    'title'        => "Super salad",
    'price'        => 20,
    'blurb'        => "Gumbo beet greens corn soko
                       endive gumbo gourd. Parsley shallot
                      courgette tatsoi pea sprouts fava bean
                       collard greens dandelion okra wakame tomato.
                       Dandelion cucumber earthnut pea peanut soko zucchini.",
    'drink'        => "club soda"
  ),
  "mexican-barbacoa" => array(
    'title'        => "mexican-barbacoa",
    'price'        => 11,
    'blurb'        => "I love fruitcake danish caramels. Tart danish pastry liquorice chocolate cake fruitcake. Bear claw gingerbread muffin I love apple pie apple pie tiramisu brownie chocolate. Sweet roll cotton candy cupcake gingerbread gummies jelly-o.
                       Muffin I love croissant I love jelly-o brownie jelly beans. Toffee I love pastry.",
    'drink'        => "Beer"
  ),
);

?>
