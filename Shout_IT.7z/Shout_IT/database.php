<?php
/**
 * Created by PhpStorm.
 * User: prash
 * Date: 7/3/2018
 * Time: 8:23 AM
 *
connect to MYsQL*/

$conn=mysqli_connect("localhost","root","","shoutit");
//Test the connection

if(mysqli_connect_errno()){
    die( 'Failed to connect to the database MySQL:'.mysqli_connect_error());
}

?>