<?php

include 'database.php';
//check if form was submitted

if(isset($_POST['submit'])) {
    $user = mysqli_real_escape_string($conn, $_POST['user']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    //set time zone
    date_default_timezone_set('America/Oklahoma');
    $time = date('h:i:s a', time());

    //validate input
    if (!isset($user) || $user == '' || !isset($message) || $message == '') {
        $error = 'All Fields are Required';
        header("Location:index.php?error=" . urlencode($error));
        exit();
    } else {
        $query = "INSERT INTO shouts (user,message,time) VALUES ('$user','$message','$time')";
        if (!mysqli_query($conn, $query)) {
            die('Error:' . mysqli_error($conn));
        } else {
            header("Location:index.php");

        }
    }

}
