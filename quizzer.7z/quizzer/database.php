<?php

//create connection credentials

$db_host = 'localhost';
$db_name = 'quizzer';
$db_user = 'root';
$pwd = '';

//create the mysqli object

$mysqli= new mysqli($db_host,$db_user,$pwd,$db_name);

//Error handler

if($mysqli->connect_error){
    printf("Connection failed to establish",$mysqli->connect_error);
    exit();
}